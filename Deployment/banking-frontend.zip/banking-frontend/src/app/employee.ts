export class Employee {
    empId: number;
    name: string;
    branchCityName: string;
}
