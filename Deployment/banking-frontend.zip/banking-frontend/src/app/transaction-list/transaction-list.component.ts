import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { TransactionService } from '../transaction.service';

@Component({
  selector: 'app-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrls: ['./transaction-list.component.css']
})
export class TransactionListComponent implements OnInit {

  transactions: Transaction[];

  constructor(private transactionService: TransactionService) { }

  ngOnInit(): void {
    this.getTransactions();
  }
 
  
  private getTransactions(){
    this.transactionService.getTransactionsList().subscribe(data => {
      this.transactions = data;
    });
  }
  
  
  // this.transactions =[{
  //   "trasactionId": 234,
  //   "fromAccNo": 999668,
  //   "toAccNo": 444455,
  //   "amount": 5000,
  //   "isDebit": true
  // },
  // {
  //   "trasactionId": 689,
  //   "fromAccNo": 343553,
  //   "toAccNo": 4446575,
  //   "amount": 7996.56,
  //   "isDebit": false
  // }]



}
