export class Transaction {
    trasactionId: number;
    fromAccNo: number;
    toAccNo: number;
    amount: number;
    isDebit: boolean;
}

