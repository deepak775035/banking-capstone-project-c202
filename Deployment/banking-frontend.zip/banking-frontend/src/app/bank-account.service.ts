import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BankAccount } from './bank-account';

@Injectable({
  providedIn: 'root'
})
export class BankAccountService {

  private baseURL = "http://localhost:8080/api/v1/bank-accounts";
  
  constructor(private httpClient: HttpClient) { }

  getBankAccountsList(): Observable<BankAccount[]>{
    return this.httpClient.get<BankAccount[]>(`${this.baseURL}`);
  }

  createBankAccount(bankAccount: BankAccount): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`,bankAccount);
  }

  deleteBankAccount(accNo: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${accNo}`);
  }


}
