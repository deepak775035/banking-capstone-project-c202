export class BankAccount {
    accNo: number;
    customerId: number;
    isSavingAccount: boolean;
    branchCityName: string;
    balance: number;
}